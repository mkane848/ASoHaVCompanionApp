/* ASoHaV content library — seed data.
   Everything here is a *definition*. Character sheets reference these by Id and never copy them,
   so an edit in the admin panel reaches every sheet on next render.
   Replace wholesale via the admin panel's bulk JSON import. */
(function () {
  const L = {};

  L.virtues = [
    { Id: 'v-might',  Name: 'Might',  Tagline: 'Physicality & Force',   Essence: 'Your raw power, athleticism, and physical capabilities.', UsageHelperText: 'To smash through a gate, wrestle a beast, or climb a mountain.' },
    { Id: 'v-mettle', Name: 'Mettle', Tagline: 'Willpower & Grit',      Essence: 'Your internal fire, your bravery in the face of the unknown, and your spiritual resilience.', UsageHelperText: 'To stare down a dragon’s gaze, resist the temptation of a cursed relic, or keep moving when your legs want to give out.' },
    { Id: 'v-heart',  Name: 'Heart',  Tagline: 'Bond & Empathy',        Essence: 'Your ability to connect with others, to inspire hope, and to act on your deepest convictions.', UsageHelperText: 'To convince a village to stand and fight, comfort a grieving companion, or sacrifice your own safety for the group’s sake.' },
    { Id: 'v-wit',    Name: 'Wit',    Tagline: 'Perception & Instinct', Essence: 'Your sharpness of mind, your ability to read a room, and your eye for the hidden or the mysterious.', UsageHelperText: 'To find the hidden latch in a ruin, realize an NPC is hiding a secret, or notice the ambush before the arrows fly.' },
    { Id: 'v-guile',  Name: 'Guile',  Tagline: 'Strategy & Subtlety',   Essence: 'Your cleverness, your dexterity, and your ability to outmaneuver or outthink an opponent.', UsageHelperText: 'To sneak past a sentry, pick a complex lock, set a clever trap, or misdirect a foe’s attention during a tense parley.' }
  ];

  L.conditions = [
    { Id: 'c-exhausted',  Name: 'Exhausted',  VirtueId: 'v-might',  RollPenalty: -2, ClearAction: 'Recover from your exhaustion by indulging in a vice and shirking responsibility.' },
    { Id: 'c-afraid',     Name: 'Afraid',     VirtueId: 'v-mettle', RollPenalty: -2, ClearAction: 'Come down from your fear by running away from something challenging.' },
    { Id: 'c-hopeless',   Name: 'Hopeless',   VirtueId: 'v-heart',  RollPenalty: -2, ClearAction: 'Absolve your guilt by punishing yourself, or blame a party member related to your guilt.' },
    { Id: 'c-irrational', Name: 'Irrational', VirtueId: 'v-wit',    RollPenalty: -2, ClearAction: 'Vent your anger by hurting someone important to you, or damage something important.' },
    { Id: 'c-distracted', Name: 'Distracted', VirtueId: 'v-guile',  RollPenalty: -2, ClearAction: 'Get over your insecurity by making a rash action without discussing it with the party.' }
  ];

  L.armorTypes = [
    { Id: 'a-physical', Name: 'Physical', Key: 'Physical', Description: 'Mundane protection — plate, hide, a shield taken on the arm.' },
    { Id: 'a-heavy',    Name: 'Heavy',    Key: 'Heavy',    Description: 'Bulk that turns a blow aside entirely.' },
    { Id: 'a-special',  Name: 'Special',  Key: 'Special',  Description: 'Warded, blessed, or otherwise uncanny protection.' }
  ];

  /* LoadCost: 0 = concealable, 1 = standard visible kit, 2 = large or cumbersome. */
  L.items = [
    { Id: 'i-sword',      Name: 'Arming sword',      LoadCost: 1, Description: 'A soldier’s blade, well balanced and unremarkable.' },
    { Id: 'i-shield',     Name: 'Kite shield',       LoadCost: 1, GrantsArmorTypeId: 'a-physical', Description: 'Battered oak faced in hide.' },
    { Id: 'i-mail',       Name: 'Coat of mail',      LoadCost: 2, GrantsArmorTypeId: 'a-heavy', Description: 'Heavy, loud, and worth every pound.' },
    { Id: 'i-bootknife',  Name: 'Boot knife',        LoadCost: 0, Description: 'Small enough that nobody counts it.' },
    { Id: 'i-rope',       Name: 'Coil of rope',      LoadCost: 1, Description: 'Fifty feet, hemp, slightly damp.' },
    { Id: 'i-lantern',    Name: 'Hooded lantern',    LoadCost: 1, Charges: 3, Description: 'Burns oil. Shutter it to hide the light.' },
    { Id: 'i-poultice',   Name: 'Field poultices',   LoadCost: 0, Charges: 3, Description: 'Spend a charge to clear a Rank of a physical Status.' },
    { Id: 'i-wardstone',  Name: 'Ward-stone',        LoadCost: 0, Charges: 1, GrantsArmorTypeId: 'a-special', Description: 'Cracks when it saves you. Once.' },
    { Id: 'i-rations',    Name: 'Trail rations',     LoadCost: 1, Description: 'A week of unpleasant but sufficient food.' },
    { Id: 'i-toolkit',    Name: 'Thief’s tools',     LoadCost: 0, Charges: 2, Description: 'Picks, wedges, a mirror on a wire.' },
    { Id: 'i-banner',     Name: 'House banner',      LoadCost: 2, Description: 'Impossible to conceal. That is the point.' }
  ];

  L.themes = [
    { Id: 't-exile', Name: 'The Exile', Description: 'You were sent away, or you left before they could send you. Somewhere behind you is a door that was shut, and you have never stopped facing it.',
      StartingQuestId: 'q-exile-1',
      QuestIds: ['q-exile-1', 'q-exile-2', 'q-exile-3', 'q-exile-4', 'q-exile-5'] },
    { Id: 't-debt', Name: 'The Debt', Description: 'Something was given to you that you did not earn, and the ledger has never balanced. You are not sure whether paying it would free you or end you.',
      StartingQuestId: 'q-debt-1',
      QuestIds: ['q-debt-1', 'q-debt-2', 'q-debt-3', 'q-debt-4'] },
    { Id: 't-oath', Name: 'The Oath', Description: 'You swore something once, plainly and in front of witnesses. The world has changed since. The words have not.',
      StartingQuestId: 'q-oath-1',
      QuestIds: ['q-oath-1', 'q-oath-2', 'q-oath-3', 'q-oath-4'] },
    { Id: 't-inheritance', Name: 'The Inheritance', Description: 'You carry something down from someone who is gone — a name, a weapon, a sickness, a duty. It did not ask whether you wanted it.',
      StartingQuestId: 'q-inh-1',
      QuestIds: ['q-inh-1', 'q-inh-2', 'q-inh-3', 'q-inh-4'] }
  ];

  L.quests = [
    { Id: 'q-exile-1', ThemeId: 't-exile', Name: 'Learn why you were truly sent away', Description: 'The reason you were given was not the reason. Find someone who was in the room.' },
    { Id: 'q-exile-2', ThemeId: 't-exile', Name: 'Return something you took with you', Description: 'You did not leave empty-handed. Give it back, or decide out loud that you never will.' },
    { Id: 'q-exile-3', ThemeId: 't-exile', Name: 'Make a place that cannot exile you', Description: 'Build, buy, or take somewhere that is yours by a claim nobody can revoke.' },
    { Id: 'q-exile-4', ThemeId: 't-exile', Name: 'Find another who was cast out', Description: 'Someone else carries this. Find them, and choose whether to help.' },
    { Id: 'q-exile-5', ThemeId: 't-exile', Name: 'Refuse an invitation home', Description: 'They will ask. Be certain of your answer before they do.' },
    { Id: 'q-debt-1', ThemeId: 't-debt', Name: 'Discover the true size of what you owe', Description: 'You have been estimating. Get the real figure.' },
    { Id: 'q-debt-2', ThemeId: 't-debt', Name: 'Pay a portion in public', Description: 'Settle part of it where people can see, and learn what that costs you.' },
    { Id: 'q-debt-3', ThemeId: 't-debt', Name: 'Refuse to pay something you owe', Description: 'Decide that one part of the ledger is unjust, and hold that line.' },
    { Id: 'q-debt-4', ThemeId: 't-debt', Name: 'Take on someone else’s debt', Description: 'Add another’s burden to yours, knowingly.' },
    { Id: 'q-oath-1', ThemeId: 't-oath', Name: 'Keep the oath when it costs you dearly', Description: 'The first real test. Pay it.' },
    { Id: 'q-oath-2', ThemeId: 't-oath', Name: 'Find the person you swore it to', Description: 'Alive or otherwise. Learn whether they still hold you to it.' },
    { Id: 'q-oath-3', ThemeId: 't-oath', Name: 'Break the oath deliberately', Description: 'Not by accident and not under duress. Choose it, and say why.' },
    { Id: 'q-oath-4', ThemeId: 't-oath', Name: 'Swear a new one', Description: 'Words, witnesses, and something at stake.' },
    { Id: 'q-inh-1', ThemeId: 't-inheritance', Name: 'Use it the way they would have', Description: 'Once, exactly as intended. Notice how it feels.' },
    { Id: 'q-inh-2', ThemeId: 't-inheritance', Name: 'Learn what they did with it', Description: 'Find out the part of the story you were not told.' },
    { Id: 'q-inh-3', ThemeId: 't-inheritance', Name: 'Put it down', Description: 'Set the inheritance aside and survive a situation without it.' },
    { Id: 'q-inh-4', ThemeId: 't-inheritance', Name: 'Choose who receives it next', Description: 'Name them, and tell them what it will cost.' }
  ];

  L.skills = [
    { Id: 's-protect',  Name: 'Protect Someone',    Effect: 'When you Invoke Expertise to defend someone, physically or emotionally, treat a 6 as if it were a 7–9.' },
    { Id: 's-ward',     Name: 'Choose a Ward',      Effect: 'You have +1 Ongoing to any action that puts your Ward’s safety ahead of something else. When you Offer Solace to your Ward, they may either mark Potential or mark Kin on your bond with them.' },
    { Id: 's-martyr',   Name: 'Martyr',             Effect: 'When you have a total of 3 Conditions or 6 negative Status Ranks, take +1 Ongoing on all moves.' },
    { Id: 's-resolve',  Name: 'Unbreakable Resolve', Effect: 'When you Stand Defiant and roll a miss, you may mark a Condition to treat it as a 7–9 instead.' },
    { Id: 's-trained',  Name: 'Trained For This',   Effect: 'Name a field of training. When you Invoke Expertise within it, take +1.' },
    { Id: 's-attention',Name: 'Center of Attention', Effect: 'When you deliberately draw every eye in a scene, hold 1. Spend it to have an ally act unnoticed.' },
    { Id: 's-unfinished', Name: 'Unfinished Business', Effect: 'Name something you left undone. While pursuing it, you cannot be made to flee.' }
  ];

  /* Global list. Filtered by Track and unlocked Tier. Repeatable ones stay selectable. */
  L.advancements = [
    { Id: 'ad-p-virtue1', Name: 'Raise a Virtue by 1',            Track: 'Potential', Tier: 1, Repeatable: true,  MaxTimes: 3, Effect: 'Increase any one Virtue by 1, to a maximum of +3.' },
    { Id: 'ad-p-skill',   Name: 'Take a new Skill',               Track: 'Potential', Tier: 1, Repeatable: true,  MaxTimes: null, Effect: 'Choose an additional Skill.' },
    { Id: 'ad-p-ability', Name: 'Take a new Ability',             Track: 'Potential', Tier: 1, Repeatable: true,  MaxTimes: null, Effect: 'Choose an additional Ability.' },
    { Id: 'ad-p-load',    Name: 'Broaden your shoulders',         Track: 'Potential', Tier: 1, Repeatable: false, MaxTimes: null, Effect: '+1 to your Light, Normal, and Heavy Load.' },
    { Id: 'ad-p-quest',   Name: 'Take an additional Quest',       Track: 'Potential', Tier: 1, Repeatable: true,  MaxTimes: 2, Effect: 'Accept one more Quest from your Theme.' },
    { Id: 'ad-p-armor',   Name: 'Harden yourself',                Track: 'Potential', Tier: 2, Repeatable: true,  MaxTimes: 2, Effect: 'Gain one additional Armor box of a type you already have.' },
    { Id: 'ad-p-cond',    Name: 'Steady heart',                   Track: 'Potential', Tier: 2, Repeatable: false, MaxTimes: null, Effect: 'When you Make Camp, clear one Condition of your choice in addition to normal recovery.' },
    { Id: 'ad-p-theme',   Name: 'Change your Theme',              Track: 'Potential', Tier: 2, Repeatable: false, MaxTimes: null, Effect: 'Retire your current Theme and choose another. Completed Quests remain completed.' },
    { Id: 'ad-p-status',  Name: 'Weather the storm',              Track: 'Potential', Tier: 3, Repeatable: false, MaxTimes: null, Effect: 'When you Make Camp, clear 1 additional Rank of negative Statuses.' },
    { Id: 'ad-p-second',  Name: 'A second calling',               Track: 'Potential', Tier: 3, Repeatable: false, MaxTimes: null, Effect: 'Take two Abilities at once.' },
    { Id: 'ad-p-legend',  Name: 'Become a legend',                Track: 'Potential', Tier: 4, Repeatable: false, MaxTimes: null, Effect: 'Your name precedes you. Once per session, declare that someone has heard of you and say what they believe.' },
    { Id: 'ad-p-defy',    Name: 'Defy the ending',                Track: 'Potential', Tier: 4, Repeatable: false, MaxTimes: null, Effect: 'Once, when you would be removed from the story, you are not. Describe what it costs.' },
    { Id: 'ad-r-rapport', Name: 'Deepen the company',             Track: 'Rapport',   Tier: 1, Repeatable: false, MaxTimes: null, Effect: 'The party’s Rapport Track gains a sixth box.' },
    { Id: 'ad-r-camp',    Name: 'A better camp',                  Track: 'Rapport',   Tier: 1, Repeatable: false, MaxTimes: null, Effect: 'When you Make Camp, one party member of your choosing clears an additional Condition.' },
    { Id: 'ad-r-help',    Name: 'Second wind',                    Track: 'Rapport',   Tier: 1, Repeatable: true,  MaxTimes: 2, Effect: 'A party member may spend a second Rapport on the same roll.' },
    { Id: 'ad-r-signal',  Name: 'Wordless understanding',         Track: 'Rapport',   Tier: 2, Repeatable: false, MaxTimes: null, Effect: 'Spend a Rapport to communicate a full sentence with any party member in line of sight, silently.' },
    { Id: 'ad-r-standard',Name: 'Raise a standard',               Track: 'Rapport',   Tier: 2, Repeatable: false, MaxTimes: null, Effect: 'The party takes a name and a symbol. When you invoke it publicly, take +1 forward as a group.' },
    { Id: 'ad-r-lastline',Name: 'The last line',                  Track: 'Rapport',   Tier: 3, Repeatable: false, MaxTimes: null, Effect: 'When the whole party spends Rapport on one roll, treat a miss as a 10+.' }
  ];

  /* Prose is authoritative; Effects are optional structured metadata for a future rules engine.
     Kinds: VirtueBoost, RollBonus, GrantArmor, GrantMove, ModifyMove, GrantStatus, ResourceChange, Hold, Narrative
     Duration: Permanent | Ongoing | Forward | Instant | WhileConditionHolds */
  L.abilities = [
    { Id: 'ab-ironclad', Name: 'Ironclad', Acquisition: 'Starting', Tags: ['defense'],
      RulesText: 'You have learned to take a hit so that someone else does not. Gain 1 Physical Armor.',
      Effects: [{ Kind: 'GrantArmor', ArmorTypeId: 'a-physical', Count: 1, Duration: 'Permanent' }] },
    { Id: 'ab-resolve', Name: 'Unbreakable', Acquisition: 'Starting', Tags: ['mettle'],
      RulesText: 'Whatever they did to you, it did not take. Permanently increase your Mettle by 1.',
      Effects: [{ Kind: 'VirtueBoost', VirtueId: 'v-mettle', Value: 1, Duration: 'Permanent' }] },
    { Id: 'ab-attention', Name: 'Center of Attention', Acquisition: 'Advancement', Tags: ['social'],
      RulesText: 'When you make yourself the loudest thing in the room, take +2 Ongoing to Sway the Spirit until you leave the scene or someone louder arrives.',
      Effects: [{ Kind: 'RollBonus', Value: 2, Duration: 'Ongoing', AppliesToMoveId: 'm-sway', TriggerText: 'While you are the loudest thing in the room' }] },
    { Id: 'ab-ward', Name: 'Sworn Ward', Acquisition: 'Advancement', Tags: ['social', 'bond'],
      RulesText: 'Name another character as your Ward. Take +1 Ongoing to any action that puts their safety ahead of something else. If your Ward dies, mark all your Conditions.',
      Effects: [
        { Kind: 'RollBonus', Value: 1, Duration: 'Ongoing', TriggerText: 'On any action putting your Ward’s safety first' },
        { Kind: 'Narrative', Text: 'If your Ward dies, mark all your Conditions.' }
      ] },
    { Id: 'ab-martyr', Name: 'Martyr', Acquisition: 'Advancement', Tags: ['mettle'],
      RulesText: 'You work best in ruin. While you carry 3 or more Conditions, take +1 Ongoing on all moves.',
      Effects: [{ Kind: 'RollBonus', Value: 1, Duration: 'WhileConditionHolds', TriggerText: 'While carrying 3 or more Conditions' }] },
    { Id: 'ab-readall', Name: 'Read the Room', Acquisition: 'Starting', Tags: ['wit'],
      RulesText: 'When you Assess the Situation, add “What here is about to change?” to the question list, and hold 1 extra on a 10+.',
      Effects: [
        { Kind: 'ModifyMove', MoveId: 'm-assess', AddedOptions: ['What here is about to change?'] },
        { Kind: 'Hold', Count: 1, SpendText: 'Extra hold on a 10+ when you Assess the Situation.' }
      ] },
    { Id: 'ab-quiet', Name: 'Quiet Hands', Acquisition: 'Starting', Tags: ['guile'],
      RulesText: 'Items you carry that cost 0 Load are never found by a casual search, and you may carry one 1-Load item as though it cost 0.',
      Effects: [{ Kind: 'ResourceChange', Resource: 'Load', Value: 1, Duration: 'Permanent' }] },
    { Id: 'ab-wardstone', Name: 'Stonebound', Acquisition: 'Item', Tags: ['special'],
      RulesText: 'While you carry a ward-stone, gain 1 Special Armor. When it breaks, gain Rattled 2.',
      Effects: [
        { Kind: 'GrantArmor', ArmorTypeId: 'a-special', Count: 1, Duration: 'Ongoing', TriggerText: 'While carrying a ward-stone' },
        { Kind: 'GrantStatus', StatusName: 'Rattled', Polarity: 'Negative', Rank: 2, TriggerText: 'When the stone breaks' }
      ] }
  ];

  /* Tier3 = 10+, Tier2 = 7–9, Tier1 = miss. */
  L.moves = [
    { Id: 'm-defiant', Name: 'Stand Defiant', Kind: 'Basic', VirtueId: 'v-mettle',
      Description: 'When you weather an assault on the mind, body, or spirit, try to resist the urge to flee, or endure excruciating agony to hold your ground and stand defiant against it, roll +Mettle.',
      Results: {
        Tier3: { Description: 'You are unshakeable. You shrug off the pressure and gain a momentary advantage — take +1 forward against the source of the threat.', Options: [], ChooseCount: 0 },
        Tier2: { Description: 'You hold firm, but the effort costs you. Choose one:', ChooseCount: 1, Options: [
          'You feel shaken from the conflict; mark a Condition.',
          'You don’t come out unscathed. Take Rattled 2 (or similar).',
          'To push through costs you. Make a sacrifice to do it — name what that is and the GM will tell you if it is enough.'] },
        Tier1: { Description: 'The pressure breaks you. You flinch, flee, or collapse, and the GM makes a move.', Options: [], ChooseCount: 0 }
      } },
    { Id: 'm-solace', Name: 'Offer Solace', Kind: 'Basic', VirtueId: 'v-heart',
      Description: 'When you try to comfort or support someone by offering solace and speaking from the heart, roll +Heart.',
      Results: {
        Tier3: { Description: 'If they open up to you, they either mark Potential, clear a Condition, or you reduce one of their negative Statuses by 2 Ranks (or increase a positive Status by 2). Additionally, mark Rapport or one Kin with them.', Options: [], ChooseCount: 0 },
        Tier2: { Description: 'If they open up to you, they either mark Potential, clear a Condition, or shift a Status 2 Ranks.', Options: [], ChooseCount: 0 },
        Tier1: { Description: 'Your approach was completely wrong. Mark a Condition or lose one Kin with them.', Options: [], ChooseCount: 0 }
      } },
    { Id: 'm-sway', Name: 'Sway the Spirit', Kind: 'Basic', VirtueId: 'v-heart',
      Description: 'When trying to sway the spirit by using empathy, honesty, or comfort to get someone to do what you want, roll +Heart.',
      Results: {
        Tier3: { Description: 'They do as you ask to the best of their ability. If you’ve asked too much, they’ll tell you what it would take for them to do it.', Options: [], ChooseCount: 0 },
        Tier2: { Description: 'They are willing, but the GM will choose one:', ChooseCount: 1, Options: [
          'Gain Indebted 2. You owe them a promise, a payment, or a favor in return. The more you ask, the more they’ll ask in return. They may demand it upfront.',
          'They only follow through on a portion of your request, or will only do it after revealing a hard truth to you. GM’s choice.',
          'The act or their answer puts them in danger; take −1 forward with them due to the friction.'] },
        Tier1: { Description: 'You reveal a vulnerability or offend them. If they choose to do what you ask, the favor you must do for them is particularly costly, challenging, or undignified. In any situation, the GM makes a Hard Move.', Options: [], ChooseCount: 0 }
      },
      PlayerVariantResults: {
        Tier3: { Description: 'They mark Potential or Kin between you, and get +1 forward if they do what you ask.', Options: [], ChooseCount: 0 },
        Tier2: { Description: 'They mark Potential or Kin between you if they do what you ask.', Options: [], ChooseCount: 0 },
        Tier1: { Description: 'It’s up to that player to decide how badly you offend or annoy them. Remove one Kin between you. They mark Potential if they do not do what you asked.', Options: [], ChooseCount: 0 }
      } },
    { Id: 'm-gut', Name: 'Trust Your Gut', Kind: 'Basic', VirtueId: 'v-heart',
      Description: 'When trying to discern the truth by scrutinizing someone in a probing conversation or in a moment of vulnerability, roll +Heart.',
      Results: {
        Tier3: { Description: 'Hold 2 and gain Insightful 2. While interacting with them, spend your hold 1-for-1 to ask a question of either the GM or player; they must answer truthfully.', ChooseCount: 0, Options: [
          'Are they telling the truth about ______?', 'What are they truly feeling?', 'What are their real intentions?', 'What do they wish I would do?', 'How could I get them to ______?', 'What do they desire or fear?'] },
        Tier2: { Description: 'Hold 1 and gain Insightful 1, but choose one complication. While interacting with them, spend your hold 1-for-1 to ask a question; they must answer truthfully.', ChooseCount: 1, Options: [
          'You find your answers the hard way. Mark a Condition.',
          'What you find out puts you in imminent danger.',
          'You reveal something to your enemies.'] },
        Tier1: { Description: 'You misread them completely, believing a complete untruth, or your pursuits reveal something important to your enemies. Mark Potential and the GM takes or holds a Hard Move.', Options: [], ChooseCount: 0 }
      } },
    { Id: 'm-assess', Name: 'Assess the Situation', Kind: 'Basic', VirtueId: 'v-wit',
      Description: 'When you assess the situation to figure out what is going on in a moment of risk or conflict, roll +Wit. If no risk or conflict is present, say how you do it to ask the GM any question.',
      Results: {
        Tier3: { Description: 'Hold 3. Take +1 ongoing while acting on any answers.', ChooseCount: 0, Options: [
          'What here is concealed by magical or mundane means?', 'What’s my best way out, in, or through?', 'What here can I use to ______?', 'Who or what here is the greatest threat, or in the greatest danger?', 'What is the true nature of ______?', 'How can we best end this quickly?'] },
        Tier2: { Description: 'Hold 1, or hold 2 and choose one complication. Take +1 ongoing while acting on any answers.', ChooseCount: 1, Options: [
          'You find your answers the hard way. Mark a Condition.',
          'What you find out puts you in imminent danger; the GM will say how after you choose this.',
          'There’s a complication either with what you find or how you find it. Take a negative Status at Rank 2.',
          'You reveal something to your enemies by leaving something behind or by other means.',
          'Your investigation draws immediate and unwanted attention.'] },
        Tier1: { Description: 'You find your answer, but it is the worst possible news. Mark Potential and the GM takes or holds a Hard Move.', Options: [], ChooseCount: 0 }
      } },
    { Id: 'm-past', Name: 'Consult the Past', Kind: 'Basic', VirtueId: 'v-wit',
      Description: 'When you search your memory for lore, history, or professional knowledge regarding a subject, consult the past. State how you might know this and roll +Wit. If you have access to a book or similar record, roll with advantage.',
      Results: {
        Tier3: { Description: 'The GM will tell you the detailed, useful truth. You and any allies you brief take +1 Ongoing while acting on this knowledge, and gain Prepared 2.', Options: [], ChooseCount: 0 },
        Tier2: { Description: 'The GM will tell you a vague or incomplete truth. The information may reveal a new complication or danger. You and any allies you brief take +1 Forward while acting on this knowledge, and gain Prepared 2.', Options: [], ChooseCount: 0 },
        Tier1: { Description: 'The answer reveals how bad things really are, or a danger you’re barreling toward. The GM makes a move.', Options: [], ChooseCount: 0 }
      } },
    { Id: 'm-answer', Name: 'Find the Answer', Kind: 'Basic', VirtueId: 'v-wit',
      Description: 'When trying to find the answer by connecting the dots, roll +Wit.',
      Results: {
        Tier3: { Description: 'Hold 2 and gain Sharp 2. While working on the problem, spend your hold 1-for-1 to ask a question; they must answer truthfully.', Options: [], ChooseCount: 0 },
        Tier2: { Description: 'Hold 1 and gain Sharp 1, but choose one complication. Spend your hold 1-for-1 to ask a question; they must answer truthfully.', ChooseCount: 1, Options: ['You find your answers the hard way. Mark a Condition.', 'Your work draws unwanted attention.'] },
        Tier1: { Description: 'You miscalculate completely, believing a complete untruth, or your pursuits reveal something important to your enemies. Mark Potential and the GM takes or holds a Hard Move.', Options: [], ChooseCount: 0 }
      } },
    { Id: 'm-lead', Name: 'Follow a Lead', Kind: 'Basic', VirtueId: 'v-guile',
      Description: 'When you try to find something or someone by asking around, tracking a trail, or opening up your senses, roll +Guile. If you are following a lead by gathering rumors and information, you may spend 1 Wealth to roll with advantage.',
      Results: {
        Tier3: { Description: 'Choose one dilemma below. Then you find them or it. You may ask one follow-up question about the destination or the journey.', ChooseCount: 1, Options: [
          'The search has many obstacles and detours. All PCs in pursuit mark a Condition or take Fatigue 2.',
          'You’ve been noticed. It may be by your quarry, or by someone or something else.',
          'You’ve been held up. Some significant obstacle now stands in your way.',
          'Your pursuit reveals information or a vulnerability to your quarry or their allies.',
          'You find them, but it takes too much time. The GM advances a threat.',
          'You find the lead, but it reveals something that complicates your mission.'] },
        Tier2: { Description: 'Choose two dilemmas below. Then you find them or it.', ChooseCount: 2, Options: [
          'The search has many obstacles and detours. All PCs in pursuit mark a Condition or take Fatigue 2.',
          'You’ve been noticed. It may be by your quarry, or by someone or something else.',
          'You’ve been held up. Some significant obstacle now stands in your way.',
          'Your pursuit reveals information or a vulnerability to your quarry or their allies.',
          'You find them, but it takes too much time. The GM advances a threat.',
          'You find the lead, but it reveals something that complicates your mission.'] },
        Tier1: { Description: 'You find what you’re looking for, but at great cost. Choose three dilemmas. The GM then makes a move.', ChooseCount: 3, Options: [
          'The search has many obstacles and detours. All PCs in pursuit mark a Condition or take Fatigue 2.',
          'You’ve been noticed. It may be by your quarry, or by someone or something else.',
          'You’ve been held up. Some significant obstacle now stands in your way.',
          'Your pursuit reveals information or a vulnerability to your quarry or their allies.',
          'You find them, but it takes too much time. The GM advances a threat.',
          'You find the lead, but it reveals something that complicates your mission.'] }
      } },
    { Id: 'm-expertise', Name: 'Invoke Expertise', Kind: 'Basic', VirtueId: null,
      Description: 'When you attempt to overcome an obstacle or take out enemies not worth Combat using a relevant Skill or Background, say your goal and roll + an appropriate Virtue. The GM will tell you if what you are trying to do can’t be accomplished.',
      Results: {
        Tier3: { Description: 'You do what you intended; describe what it looks like.', Options: [], ChooseCount: 0 },
        Tier2: { Description: 'Your actions leave you vulnerable. You do what you intended but must choose one consequence:', ChooseCount: 1, Options: [
          'Gain Exposed 2 and draw unwanted attention or leave a traceable trail.',
          'Gain Compromised 2 and the situation escalates; you run out of the frying pan and into the fire.',
          'Gain Delayed 2 and you take too long; the situation around you changes in a meaningful way.',
          'Attrition: expend a resource or break a useful item.',
          'Sacrifice: you receive a worse outcome, hard choice, or price to pay.'] },
        Tier1: { Description: 'Your skills and training aren’t enough here. The GM takes or holds a Hard Move.', Options: [], ChooseCount: 0 }
      } },
    { Id: 'm-risk', Name: 'Take a Risk', Kind: 'Basic', VirtueId: null,
      Description: 'When you attempt to overcome an obstacle or take out enemies not worth Combat without a relevant Skill or Background, say your goal and roll + an appropriate Virtue.',
      Results: {
        Tier3: { Description: 'You achieve your goal, but at a cost; choose one consequence.', ChooseCount: 1, Options: [
          'Attrition: expend a resource or break a useful item.', 'Detection: draw unwanted attention or leave a traceable trail.', 'Danger: the situation escalates.', 'Delay: you take too long; the situation changes meaningfully.', 'Sacrifice: a worse outcome, hard choice, or price to pay.'] },
        Tier2: { Description: 'You achieve your goal, but things get messy. The GM chooses one consequence.', ChooseCount: 1, Options: [
          'Attrition: expend a resource or break a useful item.', 'Detection: draw unwanted attention or leave a traceable trail.', 'Danger: the situation escalates.', 'Delay: you take too long; the situation changes meaningfully.', 'Sacrifice: a worse outcome, hard choice, or price to pay.'] },
        Tier1: { Description: 'Things go south. The GM takes or holds a Hard Move.', Options: [], ChooseCount: 0 }
      } },
    { Id: 'm-push', Name: 'Push Yourself', Kind: 'Adventure', VirtueId: null,
      Description: 'When you push yourself past what you should be able to do, mark a Condition and take +1 to the roll. You may add a further +1 if a Skill applies.',
      Results: {
        Tier3: { Description: 'You do it, and it costs only what you already paid.', Options: [], ChooseCount: 0 },
        Tier2: { Description: 'You do it, but take a negative Status at Rank 2 of the GM’s choosing.', Options: [], ChooseCount: 0 },
        Tier1: { Description: 'You fall short and the Condition is spent for nothing. The GM makes a move.', Options: [], ChooseCount: 0 }
      } },
    { Id: 'm-camp', Name: 'Make Camp', Kind: 'Adventure', VirtueId: null,
      Description: 'When you make camp in relative safety, clear 2D6 Ranks of negative Statuses and 1D6 Ranks of positive Statuses across the party, refresh all Armor, and choose your Load for the next leg of the journey.',
      Results: {
        Tier3: { Description: 'No roll. Camp always works — the question is what it costs you in time.', Options: [], ChooseCount: 0 },
        Tier2: { Description: '—', Options: [], ChooseCount: 0 },
        Tier1: { Description: '—', Options: [], ChooseCount: 0 }
      } },
    { Id: 'm-session', Name: 'End the Session', Kind: 'Adventure', VirtueId: null,
      Description: 'At the end of each session, mark Rapport. Then, as a table, name what changed and who changed it.',
      Results: {
        Tier3: { Description: 'No roll.', Options: [], ChooseCount: 0 },
        Tier2: { Description: '—', Options: [], ChooseCount: 0 },
        Tier1: { Description: '—', Options: [], ChooseCount: 0 }
      } }
  ];

  /* Game settings — editable from the admin panel. */
  L.settings = {
    Id: 'set-1',
    AbilitiesAtCreation: 2,
    PotentialTrackLength: 5,
    RapportTrackLength: 5,
    KinTrackLength: 5,
    StatusMaxRank: 6,
    ConditionFloor: -3
  };

  L.loadTiers = [
    { Key: 'Light',  Base: 3, Note: 'You move quickly, have +1 Speed in Combat, and are relatively inconspicuous.' },
    { Key: 'Normal', Base: 5, Note: 'You move normally and look like a prepared adventurer.' },
    { Key: 'Heavy',  Base: 6, Note: 'You move slower than normal, have −1 Speed in Combat, and look like a particularly armed combatant.' }
  ];

  L.byId = function (coll, id) { return (L[coll] || []).find(function (x) { return x.Id === id; }) || null; };

  window.ASoHaVLibrary = L;
})();
